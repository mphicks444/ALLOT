// app.jsx — ALLOT Studio entry

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "bone",
  "displayFont": "serif",
  "density": "regular",
  "accent": "#B45A33"
}/*EDITMODE-END*/;

const PALETTES = [
  { id: "bone",     swatch: ["#F2EFE7", "#15130F", "#B45A33"] },
  { id: "charcoal", swatch: ["#16140F", "#F0EBDD", "#E0875A"] },
  { id: "oat",      swatch: ["#EDE6D2", "#1A1610", "#5C3A1E"] },
];

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [activeSection, setActiveSection] = React.useState("top");

  // Apply palette + font + density via body data-attrs
  React.useEffect(() => {
    document.body.dataset.palette = t.palette;
    document.body.dataset.displayFont = t.displayFont;
    document.body.dataset.density = t.density;
    document.documentElement.style.setProperty("--accent",
      t.palette === "charcoal" ? "#E0875A" :
      t.palette === "oat" ? "#5C3A1E" : t.accent || "#B45A33"
    );
  }, [t.palette, t.displayFont, t.density, t.accent]);

  // Track active section for nav indicator
  React.useEffect(() => {
    const ids = ["top", "about", "services", "clients", "principles", "equity", "future", "contact"];
    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible[0]) setActiveSection(visible[0].target.id);
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: [0, 0.25, 0.5] }
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  return (
    <>
      <Nav activeSection={activeSection} />
      <Ticker />
      <main>
        <Hero />
        <About />
        <Services />
        <Clients />
        <Principles />
        <Equity />
        <Future />
        <Contact />
      </main>
      <Footer />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Palette" />
        <TweakRadio
          label="Theme"
          value={t.palette}
          options={["bone", "charcoal", "oat"]}
          onChange={(v) => setTweak("palette", v)}
        />
        <TweakColor
          label="Accent"
          value={t.accent}
          options={["#B45A33", "#7A5C3A", "#3E5C45", "#1F3A5F", "#8B2E2E"]}
          onChange={(v) => setTweak("accent", v)}
        />

        <TweakSection label="Type" />
        <TweakRadio
          label="Display"
          value={t.displayFont}
          options={["serif", "sans"]}
          onChange={(v) => setTweak("displayFont", v)}
        />

        <TweakSection label="Layout" />
        <TweakRadio
          label="Density"
          value={t.density}
          options={["compact", "regular", "comfy"]}
          onChange={(v) => setTweak("density", v)}
        />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
