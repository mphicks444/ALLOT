// sections.jsx — ALLOT Studio homepage sections
// Exported via window for app.jsx consumption.

const { useEffect, useState, useRef } = React;

// ─── NAV ───────────────────────────────────────────────────────────────────
function Nav({ activeSection }) {
  const links = [
    { id: "about",      label: "Studio" },
    { id: "services",   label: "Services" },
    { id: "clients",    label: "Clients" },
    { id: "principles", label: "Approach" },
    { id: "equity",     label: "Engagement" },
    { id: "contact",    label: "Contact" },
  ];
  return (
    <header className="nav">
      <div className="container nav-inner">
        <a href="#top" className="brand" aria-label="ALLOT Studio">
          <span className="mark">A</span>
          <span>ALLOT</span>
          <span className="sep">/</span>
          <span className="role">Studio</span>
        </a>
        <nav className="nav-links" aria-label="Primary">
          {links.map((l) => (
            <a key={l.id}
               href={`#${l.id}`}
               className="nav-link"
               data-active={activeSection === l.id ? "true" : "false"}>
              {l.label}
            </a>
          ))}
        </nav>
        <a href="#contact" className="nav-cta">
          Begin a conversation <span className="arr">↗</span>
        </a>
      </div>
    </header>
  );
}

// ─── TICKER ────────────────────────────────────────────────────────────────
function Ticker() {
  const items = [
    "Now engaging — Spring/Summer 2026 cohort",
    "Currently working with founders in beverage, wellness, pantry, and home",
    "Open to hybrid + equity engagements for select brands",
    "Studio operations from New York and Los Angeles",
  ];
  const doubled = [...items, ...items];
  return (
    <div className="ticker" aria-hidden="true">
      <div className="ticker-track">
        {doubled.map((t, i) => <span key={i}>{t}</span>)}
      </div>
    </div>
  );
}

// ─── HERO ──────────────────────────────────────────────────────────────────
function Hero() {
  return (
    <section id="top" className="hero">
      <div className="container">
        <div className="eyebrow"><span className="dot"></span>A growth studio for early-stage CPG · Est. 2024</div>

        <h1 className="h-display" style={{ marginTop: 36 }}>
          Visibility,<br/>
          with <em>velocity.</em>
        </h1>

        <p className="lede" style={{ marginTop: 36 }}>
          ALLOT Studio is a marketing, media, experiential, and business
          development partner for founders translating early traction into
          category presence — and category presence into enterprise value.
        </p>

        <div className="cta-row" style={{ marginTop: 40 }}>
          <a href="#contact" className="btn btn-primary">
            <span className="dot"></span>
            Begin a conversation
            <span className="arr">↗</span>
          </a>
          <a href="#services" className="btn btn-ghost">
            View our services
            <span className="arr">→</span>
          </a>
        </div>

        <div className="hero-meta">
          <div className="cell">
            <span className="mono lbl">Practice areas</span>
            <span className="val">Marketing, Media,<br/>Experiential, BD</span>
          </div>
          <div className="cell">
            <span className="mono lbl">Sector focus</span>
            <span className="val">Early-stage CPG<br/>+ adjacent consumer</span>
          </div>
          <div className="cell">
            <span className="mono lbl">Engagement</span>
            <span className="val">Retainer, project,<br/>and hybrid / equity</span>
          </div>
          <div className="cell">
            <span className="mono lbl">Studio</span>
            <span className="val">New York &amp; Los&nbsp;Angeles<br/>By introduction</span>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── ABOUT / POSITIONING ───────────────────────────────────────────────────
function About() {
  return (
    <section id="about" className="section about">
      <div className="container cols-12">
        <div className="label">
          <div className="eyebrow"><span className="dot"></span>01 — The Studio</div>
        </div>
        <div className="text">
          <h2 className="h-section">
            We sit between the <em>boardroom</em> and the <em>culture.</em>
          </h2>
          <p className="body-l" style={{ marginTop: 36 }}>
            ALLOT operates as the strategic counterpart to founders building the
            next generation of consumer brands. We design and run growth systems
            across four disciplines — marketing, media, experiential, and
            business development — and integrate them into a single momentum
            engine.
          </p>
          <p className="body-l">
            We are not a campaign shop. We are not a content house. We are a
            studio that compounds attention into distribution, distribution
            into trust, and trust into long-term enterprise value.
          </p>
        </div>

        <div className="pull">
          <div className="num">¶</div>
          <div className="body">
            <p className="body-l" style={{ margin: 0 }}>
              Most growth work today is fragmented across vendors who don't
              speak the same language. ALLOT brings the pieces — creative,
              media, retail, partnerships, sponsorship, and BD — under one
              integrated thesis, on one operating cadence.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── SERVICES ──────────────────────────────────────────────────────────────
const SERVICES = [
  {
    id: "experiential",
    title: "Experiential Marketing & Events",
    body: "Hosted experiences, dinners, residencies, and brand activations engineered to convert attention into relationships, press, and distribution.",
    tags: ["Brand events", "Activations", "Hosted dinners", "Pop-ups", "Press moments"],
  },
  {
    id: "partnerships",
    title: "Partnerships, Sponsorship & BD",
    body: "We architect the partnerships, sponsorships, and commercial relationships that move brands from interesting to inevitable — and unlock distribution that paid media cannot buy.",
    tags: ["Partnership strategy", "Sponsorship", "Co-marketing", "Strategic BD"],
  },
  {
    id: "retail",
    title: "Retail & In-Person Presence",
    body: "Retail readiness, account introductions, merchandising, and in-store storytelling for brands building physical surface area alongside digital.",
    tags: ["Retail strategy", "Merchandising", "Field marketing", "Trade"],
  },
  {
    id: "digital",
    title: "Digital Marketing & Growth",
    body: "Performance, owned channels, content systems, and influence — operated as one growth surface rather than a stack of disconnected channels.",
    tags: ["Performance", "Influence", "Owned media", "Lifecycle"],
  },
  {
    id: "visibility",
    title: "Brand Visibility Strategy",
    body: "The connective tissue. We define where a brand should be seen, by whom, and in what register — across cultural, commercial, and capital audiences.",
    tags: ["Positioning", "Editorial", "PR strategy", "Cultural calendar"],
  },
];

function Services() {
  return (
    <section id="services" className="section services">
      <div className="container">
        <div className="head">
          <div>
            <div className="eyebrow"><span className="dot"></span>02 — Practice</div>
            <h2 className="h-section" style={{ marginTop: 24 }}>
              Five disciplines.<br/>One <em>operating system.</em>
            </h2>
          </div>
          <p className="lede">
            Each discipline is built to stand alone. They are designed to
            compound when run together — which is how we prefer to work.
          </p>
        </div>

        <div className="services-list">
          {SERVICES.map((s, i) => (
            <article className="svc" key={s.id} id={s.id}>
              <div className="num">{String(i + 1).padStart(2, "0")} / 05</div>
              <h3 className="title">{s.title}</h3>
              <div className="body">
                <p style={{ margin: 0 }}>{s.body}</p>
                <div className="tags">
                  {s.tags.map((t) => <span key={t} className="tag">{t}</span>)}
                </div>
              </div>
              <div className="arrow">↗</div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── CLIENTS ───────────────────────────────────────────────────────────────
const CRITERIA = [
  { label: "Early traction with a credible thesis",
    desc: "Revenue, repeat behavior, or signal that the product is finding the right people." },
  { label: "Aligned ambition",
    desc: "Founders building a category leader — not a lifestyle business or a quick exit." },
  { label: "Cultural or category upside",
    desc: "A brand the right people would talk about if they encountered it in the right context." },
  { label: "Taste — or the discernment to recognize it",
    desc: "A point of view about how the brand should look, sound, and behave in the world." },
];

function Clients() {
  return (
    <section id="clients" className="section clients">
      <div className="container">
        <div className="grid">
          <div>
            <div className="eyebrow"><span className="dot"></span>03 — Who we work with</div>
            <h2 className="h-section" style={{ marginTop: 24 }}>
              Brands that should be more <em>visible</em> than they are.
            </h2>
            <p className="body-l" style={{ marginTop: 28, maxWidth: "44ch" }}>
              We partner with a small, deliberate roster of early-stage CPG
              brands each year. Selection is mutual; engagement is concentrated.
            </p>

            <ul className="criteria">
              {CRITERIA.map((c, i) => (
                <li key={c.label}>
                  <span className="num">{String(i + 1).padStart(2, "0")}</span>
                  <div>
                    <span className="label">{c.label}</span>
                    <span className="desc">{c.desc}</span>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="field-card" aria-hidden="true">
            <div className="stripes"></div>
            <div className="corner"></div>
            <div className="corner tr"></div>
            <div className="corner bl"></div>
            <div className="corner br"></div>
            <div className="center-mark">A</div>
            <div className="legend">
              <span>Plate&nbsp;01 · Studio mark</span>
              <span>Drop image →</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── PRINCIPLES (HOW WE THINK) ─────────────────────────────────────────────
const PRINCIPLES = [
  { stmt: <>Growth is <em>more</em> than ads.</>,
    gloss: "Paid media buys reach. It rarely buys belief. We design for both, and treat ads as one instrument inside a larger composition." },
  { stmt: <>Relevance <em>compounds.</em></>,
    gloss: "Showing up in the right rooms, alongside the right partners, in the right register — repeated patiently — is the most under-priced asset in early-stage CPG." },
  { stmt: <>Visibility should be intentional, <em>not loud.</em></>,
    gloss: "The brands that endure are not the ones that shout. They are the ones placed precisely, and seen by the right people first." },
  { stmt: <>Strong brands work on <em>culture</em> and <em>capital</em> simultaneously.</>,
    gloss: "Founders who treat brand and BD as the same workstream raise faster, sell better, and partner from a position of taste." },
  { stmt: <>Modern growth is <em>omnichannel</em> by default.</>,
    gloss: "Online and offline are not separate funnels. We plan and measure them as one continuous surface." },
  { stmt: <>Partnerships and sponsorships <em>accelerate</em> trust.</>,
    gloss: "The right collaboration says more in a week than a quarter of media. We treat this as core operating leverage." },
];

function Principles() {
  return (
    <section id="principles" className="section principles">
      <div className="container">
        <div className="cols-12" style={{ alignItems: "end" }}>
          <div style={{ gridColumn: "span 5" }}>
            <div className="eyebrow"><span className="dot"></span>04 — How we think</div>
            <h2 className="h-section" style={{ marginTop: 24 }}>
              Six operating <em>beliefs.</em>
            </h2>
          </div>
          <p className="lede" style={{ gridColumn: "7 / span 6", color: "rgba(242,239,231,0.72)" }}>
            The principles below shape the work, the partnerships we accept,
            and the engagements we decline. They are the studio's posture, not
            its tagline.
          </p>
        </div>

        <div className="principles-list">
          {PRINCIPLES.map((p, i) => (
            <div className="princ" key={i}>
              <div className="num">P · {String(i + 1).padStart(2, "0")}</div>
              <div>
                <div className="stmt">{p.stmt}</div>
                <span className="gloss">{p.gloss}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── EQUITY / HYBRID MODEL ─────────────────────────────────────────────────
function Equity() {
  return (
    <section id="equity" className="section equity">
      <div className="container">
        <div className="frame">
          <div className="stamp">By selection — limited partnerships</div>
          <div className="grid">
            <div className="label-col">
              <div className="eyebrow"><span className="dot"></span>05 — Engagement model</div>
              <h2 className="h-medium" style={{ marginTop: 24 }}>
                A note from the studio on <em>hybrid &amp; equity engagements.</em>
              </h2>
            </div>
            <div>
              <p className="body-l" style={{ marginTop: 0 }}>
                For a small number of brands each year, ALLOT structures hybrid
                engagements — deferred fees, performance milestones, or
                participation through equity or warrants. We reserve this model
                for partnerships where we are convinced of the founder, the
                category, and our ability to materially shift the trajectory.
              </p>
              <p className="body-l">
                When we work this way, we work as operators: present in the
                weekly rhythm, accountable to outcomes, and aligned with the
                cap table on the upside we help create.
              </p>

              <div className="terms">
                <div className="term">
                  <span className="key">Cash</span>
                  <span className="body">Standard retainer or scoped project. Most engagements operate here.</span>
                </div>
                <div className="term">
                  <span className="key">Hybrid</span>
                  <span className="body">Reduced cash plus performance milestones, warrants, or revenue share.</span>
                </div>
                <div className="term">
                  <span className="key">Equity</span>
                  <span className="body">Selective, founder-aligned partnerships where we participate as a long-horizon stakeholder.</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── FUTURE ────────────────────────────────────────────────────────────────
function Future() {
  return (
    <section id="future" className="section future">
      <div className="container">
        <div className="grid">
          <div>
            <div className="eyebrow"><span className="dot"></span>06 — Horizon</div>
            <h2 className="h-section" style={{ marginTop: 24 }}>
              Begins with <em>consumer.</em>
            </h2>
          </div>
          <p className="lede">
            ALLOT begins with CPG because that is where strategic visibility
            and disciplined distribution are most under-priced today. The
            studio's operating model is built to extend — patiently — into
            adjacent innovation-led categories where the same unlocks apply.
          </p>
        </div>

        <div className="stages">
          <div className="stage" data-now="true">
            <div className="yr"><span className="pip"></span>2024 — Now</div>
            <div className="name">Consumer &amp; CPG</div>
            <div className="desc">Beverage, wellness, pantry, beauty-adjacent, and home — the studio's primary practice.</div>
          </div>
          <div className="stage">
            <div className="yr"><span className="pip"></span>Next horizon</div>
            <div className="name">Consumer-tech &amp; commerce</div>
            <div className="desc">Hardware, marketplaces, and consumer software where retail and distribution remain the central unlock.</div>
          </div>
          <div className="stage">
            <div className="yr"><span className="pip"></span>Long horizon</div>
            <div className="name">Technology &amp; AI</div>
            <div className="desc">Innovation-led categories where strategic visibility, partnerships, and credibility compound the same way.</div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── CONTACT ───────────────────────────────────────────────────────────────
function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "", company: "", role: "founder", stage: "early-traction",
    intent: "engagement", message: "",
  });
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const onSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 6000);
  };

  return (
    <section id="contact" className="section contact">
      <div className="container">
        <div className="grid">
          <div>
            <div className="eyebrow"><span className="dot"></span>07 — Begin</div>
            <h2 className="h-section" style={{ marginTop: 24 }}>
              Tell us what you're <em>building.</em>
            </h2>
            <p className="body-l" style={{ marginTop: 28, maxWidth: "44ch" }}>
              We respond to every aligned inquiry within five business days.
              Please share the shape of your brand, where you are now, and what
              you'd like to be true twelve months from this conversation.
            </p>

            <form className="contact-form" onSubmit={onSubmit}>
              <div className="row">
                <div className="field">
                  <label htmlFor="f-name">Your name</label>
                  <input id="f-name" required value={form.name} onChange={set("name")} placeholder="Jane Doe" />
                </div>
                <div className="field">
                  <label htmlFor="f-company">Brand or company</label>
                  <input id="f-company" required value={form.company} onChange={set("company")} placeholder="—" />
                </div>
              </div>
              <div className="row">
                <div className="field">
                  <label htmlFor="f-role">You are a</label>
                  <select id="f-role" value={form.role} onChange={set("role")}>
                    <option value="founder">Founder / Operator</option>
                    <option value="investor">Investor</option>
                    <option value="partner">Strategic partner / Sponsor</option>
                    <option value="press">Press</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div className="field">
                  <label htmlFor="f-stage">Stage</label>
                  <select id="f-stage" value={form.stage} onChange={set("stage")}>
                    <option value="pre-launch">Pre-launch</option>
                    <option value="early-traction">Early traction</option>
                    <option value="scaling">Scaling</option>
                    <option value="not-applicable">Not applicable</option>
                  </select>
                </div>
              </div>
              <div className="field">
                <label htmlFor="f-intent">What brings you here</label>
                <select id="f-intent" value={form.intent} onChange={set("intent")}>
                  <option value="engagement">Exploring a studio engagement</option>
                  <option value="partnership">Partnership / Sponsorship inquiry</option>
                  <option value="hybrid">Hybrid / Equity engagement</option>
                  <option value="conversation">A conversation, no agenda</option>
                </select>
              </div>
              <div className="field">
                <label htmlFor="f-message">A few sentences</label>
                <textarea id="f-message" required value={form.message} onChange={set("message")}
                  placeholder="Where you are, what you're trying to make true, what's getting in the way." />
              </div>

              <div className="submit-row">
                <button type="submit" className="btn btn-primary">
                  <span className="dot"></span>
                  Send to the studio
                  <span className="arr">↗</span>
                </button>
                {submitted && <span className="ok">Received — we'll be in touch.</span>}
              </div>
            </form>
          </div>

          <aside className="contact-side">
            <div className="eyebrow"><span className="dot"></span>Currently engaging</div>

            <div className="engaging">
              <div className="row">
                <span className="key">01</span>
                <span className="val">Founders building intentional CPG brands.</span>
              </div>
              <div className="row">
                <span className="key">02</span>
                <span className="val">Sponsors looking to partner with cultural moments.</span>
              </div>
              <div className="row">
                <span className="key">03</span>
                <span className="val">Strategic operators interested in collaboration.</span>
              </div>
              <div className="row">
                <span className="key">04</span>
                <span className="val">Investors evaluating the studio's portfolio thesis.</span>
              </div>
            </div>

            <div className="channels" style={{ marginTop: 44 }}>
              <a href="mailto:studio@allot.studio">studio@allot.studio</a>
              <a href="mailto:partners@allot.studio">partners@allot.studio</a>
              <a href="#" onClick={(e) => e.preventDefault()}>Press &amp; media kit ↗</a>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

// ─── FOOTER ────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="grid">
          <div className="col lockup">
            <span className="mark">Allot</span>
            <p>A growth studio for early-stage CPG brands and the founders building what comes next.</p>
          </div>
          <div className="col">
            <h4>Studio</h4>
            <ul>
              <li><a href="#about">About</a></li>
              <li><a href="#principles">Approach</a></li>
              <li><a href="#equity">Engagement</a></li>
              <li><a href="#future">Horizon</a></li>
            </ul>
          </div>
          <div className="col">
            <h4>Practice</h4>
            <ul>
              <li><a href="#experiential">Experiential</a></li>
              <li><a href="#partnerships">Partnerships &amp; BD</a></li>
              <li><a href="#retail">Retail</a></li>
              <li><a href="#digital">Digital</a></li>
              <li><a href="#visibility">Visibility</a></li>
            </ul>
          </div>
          <div className="col">
            <h4>Contact</h4>
            <ul>
              <li><a href="mailto:studio@allot.studio">studio@allot.studio</a></li>
              <li><a href="mailto:partners@allot.studio">partners@allot.studio</a></li>
              <li><a href="#">New York · Los Angeles</a></li>
            </ul>
          </div>
        </div>
        <div className="legal">
          <span>© 2024–2026 ALLOT Studio. All rights reserved.</span>
          <span>By introduction · Limited roster</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, {
  Nav, Ticker, Hero, About, Services, Clients,
  Principles, Equity, Future, Contact, Footer,
});
